# PYTHAGORAS

A small program to show the pythagorean theorem.
Written in C with the SDL2 library.

written by 
```
  __      _     _
 / _| ___(_) __| | ___ _ __
| |_ / _ \ |/ _` |/ _ \ '__|
|  _|  __/ | (_| |  __/ |
|_|  \___|_|\__,_|\___|_|
```
for the German Blitz Basic forum (www.blitzforum.de).

Have fun!



## run
To run it on linux you need the SDL2_ttf library.

## build
To build on linux you need the SDL2 and SDL2_ttf library headers.

## windows
Prebuilt windows binaries are available.

